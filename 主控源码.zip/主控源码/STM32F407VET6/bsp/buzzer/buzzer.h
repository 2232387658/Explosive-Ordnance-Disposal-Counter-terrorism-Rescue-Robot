#ifndef __BUZZER_H__
#define __BUZZER_H__

#include "stm32f4xx.h"

extern int erro_flag;

void buzzer_Init(void);
void erro_check(void);

#endif
