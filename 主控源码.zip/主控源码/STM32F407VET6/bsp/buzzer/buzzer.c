#include "buzzer.h"
#include "key.h"

int erro_flag=0;

/******************************************************************
��������ʼ��
******************************************************************/
void buzzer_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;	

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

	GPIO_StructInit(&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin           = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode          = GPIO_Mode_OUT;
	GPIO_InitStructure.GPIO_Speed         = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType         = GPIO_OType_OD;
	GPIO_Init(GPIOE,&GPIO_InitStructure);
	
	GPIO_SetBits(GPIOE, GPIO_Pin_15);
}
/******************************************************************
���������
******************************************************************/
void erro_check()
{
	if(sure==1)
	{
		if(erro_flag==1)
		{
			GPIO_SetBits(GPIOE, GPIO_Pin_15);
		}
	}
	if(sure==0)
	{
		GPIO_SetBits(GPIOE, GPIO_Pin_15);
	}
}
