#ifndef __BSP_UART_H__
#define __BSP_UART_H__
 
#include "stm32f4xx.h"

extern uint8_t txData1,txData2,txData6,txData4;

void usart1_Init(uint32_t __Baud);
void usart2_Init(uint32_t __Baud);
void usart3_Init(uint32_t __Baud);
void usart6_Init(uint32_t __Baud);
void uart4_Init(uint32_t __Baud);
void uart5_Init(uint32_t __Baud);
void USART1_SendByte(uint8_t Byte);
void USART2_SendByte(uint8_t Byte);
void USART6_SendByte(uint8_t Byte);
#endif
