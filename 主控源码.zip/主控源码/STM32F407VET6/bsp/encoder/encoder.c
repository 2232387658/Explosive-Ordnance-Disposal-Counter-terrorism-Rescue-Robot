#include "encoder.h"

float s_time=0;
float Total_Distance_LU=0,Total_Distance_RU=0;

/***********************************************************
���ϱ�������ʼ��
***********************************************************/
void encoder_TIM4_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;  
	TIM_ICInitTypeDef TIM_ICInitStructure;  
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource12,GPIO_AF_TIM4);
	GPIO_PinAFConfig(GPIOD,GPIO_PinSource13,GPIO_AF_TIM4);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_12 | GPIO_Pin_13;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_OType = GPIO_OType_OD;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOD, &GPIO_InitStructure);

	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  
	TIM_TimeBaseStructure.TIM_Prescaler = 0x0;
	TIM_TimeBaseStructure.TIM_Period = 65535;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);

	TIM_EncoderInterfaceConfig(TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_ICStructInit(&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_ICFilter = 6;
	TIM_ICInit(TIM4, &TIM_ICInitStructure);
  
	TIM_ClearFlag(TIM4, TIM_FLAG_Update);
	TIM_ITConfig(TIM4, TIM_IT_Update, ENABLE);
	TIM_SetCounter(TIM4,0);
	TIM_Cmd(TIM4, ENABLE);
}
/***********************************************************
���ϱ�������ʼ��
***********************************************************/
void encoder_TIM5_Init(void)
{
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;  
	TIM_ICInitTypeDef TIM_ICInitStructure;  
	GPIO_InitTypeDef GPIO_InitStructure;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
	
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource0,GPIO_AF_TIM5);
	GPIO_PinAFConfig(GPIOA,GPIO_PinSource1,GPIO_AF_TIM5);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_UP;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
  
	TIM_TimeBaseStructure.TIM_Prescaler = 0;
	TIM_TimeBaseStructure.TIM_Period = 65535;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM5, &TIM_TimeBaseStructure);

	TIM_EncoderInterfaceConfig(TIM5, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising);
	TIM_ICStructInit(&TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_ICFilter = 6;
	TIM_ICInit(TIM5, &TIM_ICInitStructure);

	TIM_ClearFlag(TIM5, TIM_FLAG_Update);
	TIM_ITConfig(TIM5, TIM_IT_Update, ENABLE);
	TIM_SetCounter(TIM5,0);
	TIM_Cmd(TIM5, ENABLE);
}
/***********************************************************
��ȡ�������ٶ���ֵ
***********************************************************/
int Read_Speed(int TIMx)
{
	int value_1=0;
	switch(TIMx)
	{
		case 4:value_1=(short)TIM_GetCounter(TIM4);TIM_SetCounter(TIM4,0);break;
		case 5:value_1=(short)TIM_GetCounter(TIM5);TIM_SetCounter(TIM5,0);break;
		
		default:value_1=0;
	}
	return value_1;
}
/***********************************************************
���붨ʱ�������־λ
***********************************************************/
void TIM4_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM4,TIM_IT_Update)!=0)
	{
		TIM_ClearITPendingBit(TIM4,TIM_IT_Update);
	}
}
void TIM5_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM5,TIM_IT_Update)!=0)
	{
		TIM_ClearITPendingBit(TIM5,TIM_IT_Update);
	}
}

int Xianfu(int value,int Amplitude)
{	
	int temp;
	if(value>Amplitude) temp = Amplitude;
	else if(value<-Amplitude) temp = -Amplitude;
	else temp = value;
	return temp;
}
/***********************************************************
�����·��
***********************************************************/
void Get_Velocity(int encoder_lu,int encoder_ru)
{
    // ������ת�٣�ת/�룩
    float Rotation_Speed_LU = (encoder_lu * Control_Frequency) / (EncoderMultiples * Reduction_Ratio * Encoder_precision);
	float Rotation_Speed_RU = (encoder_ru * Control_Frequency) / (EncoderMultiples * Reduction_Ratio * Encoder_precision);
    // �����������ٶȣ�cm/s��
    float Velocity_LU = Rotation_Speed_LU * PI * (Diameter_85);
	float Velocity_RU = Rotation_Speed_RU * PI * (Diameter_85);
    // �ۼ���ʻ���루��λ��cm��
    Total_Distance_LU += -(Velocity_LU * s_time);
	Total_Distance_RU += (-Velocity_RU * s_time);
}
float Position_LU_KP=8,Position_LU_KI=0.01,Position_LU_KD=8; //PIDϵ��
float Position_RU_KP=8,Position_RU_KI=0.01,Position_RU_KD=8; //PIDϵ��

int Position_LU_PID(float position,float target)
{ 	
	static float Bias,Pwm,Integral_bias,Last_Bias;
	
	Bias=target-position;
	
	Integral_bias+=Bias;
	
	Integral_bias=Xianfu(Integral_bias,500);
	
	Pwm=Position_LU_KP*Bias+Position_LU_KI*Integral_bias+Position_LU_KD*(Bias-Last_Bias);
	
	Last_Bias=Bias; 
	
	return Pwm;
}
int Position_RU_PID(float position,float target)
{ 	
	static float Bias,Pwm,Integral_bias,Last_Bias;
	
	Bias=target-position;
	
	Integral_bias+=Bias;
	
	Integral_bias=Xianfu(Integral_bias,500);
	
	Pwm=Position_RU_KP*Bias+Position_RU_KI*Integral_bias+Position_RU_KD*(Bias-Last_Bias);
	
	Last_Bias=Bias; 
	
	return Pwm;
}
