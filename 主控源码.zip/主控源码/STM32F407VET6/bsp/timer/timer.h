#ifndef __TIMER_H__
#define __TIMER_H__

#include "stm32f4xx.h"

void TIM7_Init(u16 arr,u16 psc);
void TIM6_Init(u16 arr,u16 psc);
void TIM2_Init(u16 arr,u16 psc);
void TIM3_Init(u16 arr,u16 psc);

#endif
