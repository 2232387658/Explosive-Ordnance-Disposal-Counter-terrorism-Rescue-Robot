#ifndef __KEY_H__
#define __KEY_H__

#include "stm32f4xx.h"

extern int sure,key_count,add,subtract,mision,ceshi;

void key_Init(void);
void key_add(void);
void key_subtract(void);
void key_sure(void);
 
#endif
