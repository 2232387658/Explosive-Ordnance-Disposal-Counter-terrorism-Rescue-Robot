#include "key.h"

int add=0,subtract=0,sure=0,key_count=0,mision=0,ceshi=0;

/******************************************************************
������ʼ��
******************************************************************/
void key_Init()
{
	GPIO_InitTypeDef GPIO_InitStructure;	

	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);
	
	GPIO_StructInit(&GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin           = GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4;
	GPIO_InitStructure.GPIO_Mode          = GPIO_Mode_IN;
	GPIO_InitStructure.GPIO_Speed         = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd          = GPIO_PuPd_UP;
	
	GPIO_Init(GPIOE,&GPIO_InitStructure);
}
/******************************************************************
������
******************************************************************/
void key_add()
{
	if (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4) == 0)
	{
		while (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_4) == 0);
		add=1;
	}
	if(add==1)
	{
		key_count++;
		add=0;
	}
}
/******************************************************************
������
******************************************************************/
void key_subtract()
{
	if (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_2) == 0)
	{
		while (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_2) == 0);
		subtract=1;
	}
	if(subtract==1)
	{
		mision=1;
		subtract=0;
	}
}
/******************************************************************
����ȷ��
******************************************************************/
void key_sure()
{
	if (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3) == 0)
	{
		while (GPIO_ReadInputDataBit(GPIOE,GPIO_Pin_3) == 0);
		sure=1;
		ceshi=1;
	}
}
