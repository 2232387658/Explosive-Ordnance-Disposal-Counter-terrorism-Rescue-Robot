#ifndef	__HWT101_H__
#define __HWT101_H__

#include "board.h"
extern volatile float global_angle,global_omega;
extern float Integral_bias1,Integral_bias2;

uint8_t CalculateChecksum(uint8_t *data, uint16_t length, uint8_t type);
void ParseAndPrintData(uint8_t *data, uint16_t length);
int Angle_PID(float angle,float target);
int Aspeed_PID(float gz,float target);
void Uart4_SendArray(uint8_t *array, uint16_t length);
void Uart4_SendByte(uint8_t Byte);
#endif
