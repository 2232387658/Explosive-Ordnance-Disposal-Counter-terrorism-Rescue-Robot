#ifndef _MOTO_H
#define _MOTO_H

#include "stm32f4xx.h"

#define GPIO_AIN1              GPIO_Pin_10
#define GPIO_AIN2              GPIO_Pin_11

#define GPIO_BIN1              GPIO_Pin_14
#define GPIO_BIN2              GPIO_Pin_15

#define GPIO_CIN1              GPIO_Pin_7
#define GPIO_CIN2              GPIO_Pin_8

#define GPIO_DIN1              GPIO_Pin_10
#define GPIO_DIN2              GPIO_Pin_12

#define AIN1_OUT(X)  GPIO_WriteBit(GPIOD, GPIO_AIN1, X?Bit_SET:Bit_RESET)
#define AIN2_OUT(X)  GPIO_WriteBit(GPIOD, GPIO_AIN2, X?Bit_SET:Bit_RESET)

#define BIN1_OUT(X)  GPIO_WriteBit(GPIOD, GPIO_BIN1, X?Bit_SET:Bit_RESET)
#define BIN2_OUT(X)  GPIO_WriteBit(GPIOD, GPIO_BIN2, X?Bit_SET:Bit_RESET)

#define CIN1_OUT(X)  GPIO_WriteBit(GPIOE, GPIO_CIN1, X?Bit_SET:Bit_RESET)
#define CIN2_OUT(X)  GPIO_WriteBit(GPIOE, GPIO_CIN2, X?Bit_SET:Bit_RESET)

#define DIN1_OUT(X)  GPIO_WriteBit(GPIOE, GPIO_DIN1, X?Bit_SET:Bit_RESET)
#define DIN2_OUT(X)  GPIO_WriteBit(GPIOE, GPIO_DIN2, X?Bit_SET:Bit_RESET)

void moto_Init(uint16_t per,uint16_t pre);
void IN_GPIO_Init(void);
int abs(int p);
void moto_pwm_limit(int *speedLU,int *speedLD,int *speedRU,int *speedRD);
void Load(int speedLU,int speedLD,int speedRU,int speedRD);

#endif
