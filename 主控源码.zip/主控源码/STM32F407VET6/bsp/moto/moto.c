#include "moto.h"

int PWM_MAX=700,PWM_MIN=-700;

/************************************************
ֱ�����������ʼ��
*************************************************/
void moto_Init(uint16_t per,uint16_t pre)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef TIM_OCInitStructure;

    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1,ENABLE);
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE,ENABLE);

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9|GPIO_Pin_11|GPIO_Pin_13|GPIO_Pin_14;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_Init(GPIOE, &GPIO_InitStructure);

    GPIO_PinAFConfig(GPIOE, GPIO_PinSource9,  GPIO_AF_TIM1);
	GPIO_PinAFConfig(GPIOE, GPIO_PinSource11, GPIO_AF_TIM1);
	GPIO_PinAFConfig(GPIOE, GPIO_PinSource13, GPIO_AF_TIM1);
	GPIO_PinAFConfig(GPIOE, GPIO_PinSource14, GPIO_AF_TIM1);
	
	TIM_TimeBaseStructInit(&TIM_TimeBaseStructure);
    TIM_TimeBaseStructure.TIM_Period = per;
    TIM_TimeBaseStructure.TIM_Prescaler =pre;
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);
	
	TIM_OCStructInit(&TIM_OCInitStructure);
    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	TIM_OCInitStructure.TIM_Pulse=0;
	
    TIM_OC1Init(TIM1, &TIM_OCInitStructure);
	TIM_OC2Init(TIM1, &TIM_OCInitStructure);
	TIM_OC3Init(TIM1, &TIM_OCInitStructure);
	TIM_OC4Init(TIM1, &TIM_OCInitStructure);
	
	TIM_CtrlPWMOutputs(TIM1,ENABLE);
	
    TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC3PreloadConfig(TIM1, TIM_OCPreload_Enable);
	TIM_OC4PreloadConfig(TIM1, TIM_OCPreload_Enable);
	
	TIM_ARRPreloadConfig(TIM1,ENABLE);
	
    TIM_Cmd(TIM1, ENABLE);
	
	IN_GPIO_Init();
}
/************************************************
ֱ������������ų�ʼ��
*************************************************/
void IN_GPIO_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
    RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_14|GPIO_Pin_15;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOD, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_10|GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_OUT;
    GPIO_InitStructure.GPIO_OType = GPIO_OType_PP;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
    GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
    GPIO_Init(GPIOE, &GPIO_InitStructure);
}
/************************************************
����ֵ����
*************************************************/
int abs(int p)
{
	int q;
	q=p>0?p:(-p);
	return q;
}
/************************************************
ֱ�����PWM�޷�
*************************************************/
void moto_pwm_limit(int *speedLU,int *speedLD,int *speedRU,int *speedRD)
{
	if(*speedLU>PWM_MAX)*speedLU=PWM_MAX;
	if(*speedLU<PWM_MIN)*speedLU=PWM_MIN;
	
	if(*speedLD>PWM_MAX)*speedLD=PWM_MAX;
	if(*speedLD<PWM_MIN)*speedLD=PWM_MIN;
	
	if(*speedRU>PWM_MAX)*speedRU=PWM_MAX;
	if(*speedRU<PWM_MIN)*speedRU=PWM_MIN;
	
	if(*speedRD>PWM_MAX)*speedRD=PWM_MAX;
	if(*speedRD<PWM_MIN)*speedRD=PWM_MIN;
}
/******************************************************************
ֱ�����PWM��ֵ
******************************************************************/
void Load(int speedLU,int speedLD,int speedRU,int speedRD)
{
    if( speedLU>0 )
    {
        AIN1_OUT(0);
        AIN2_OUT(1);
    }
    else
    {
        AIN1_OUT(1);
        AIN2_OUT(0);
    }
    TIM_SetCompare1(TIM1, abs(speedLU) );
	
	if( speedLD>0 )
    {
        BIN1_OUT(0);
        BIN2_OUT(1);
    }
    else
    {
        BIN1_OUT(1);
        BIN2_OUT(0);
    }
    TIM_SetCompare2(TIM1, abs(speedLD) );
	
	if( speedRU>0 )
    {
        CIN1_OUT(0);
        CIN2_OUT(1);
    }
    else
    {
        CIN1_OUT(1);
        CIN2_OUT(0);
    }
    TIM_SetCompare3(TIM1, abs(speedRU) );
	
	if( speedRD>0 )
    {
        DIN1_OUT(0);
        DIN2_OUT(1);
    }
    else
    {
        DIN1_OUT(1);
        DIN2_OUT(0);
    }
    TIM_SetCompare4(TIM1, abs(speedRD) );
}
