#ifndef __OLED_H__
#define __OLED_H__

#include "stm32f4xx.h"

#define OLED_CMD  0	//д����

#define OLED_SCL_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_11)//SCL
#define OLED_SCL_Set() GPIO_SetBits(GPIOB,GPIO_Pin_11)

#define OLED_SDA_Clr() GPIO_ResetBits(GPIOB,GPIO_Pin_12)//SDA
#define OLED_SDA_Set() GPIO_SetBits(GPIOB,GPIO_Pin_12)

void OLED_ClearPoint(u8 x,u8 y);
void OLED_ColorTurn(u8 i);
void OLED_DisplayTurn(u8 i);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_WaitAck(void);
void Send_Byte(u8 dat);
void OLED_WR_Byte(u8 dat,u8 mode);
void OLED_Refresh(void);
void OLED_Clear(void);
void OLED_DrawPoint(u8 x,u8 y,u8 t);
void OLED_ShowChar(u8 x,u8 y,u8 chr,u8 size1,u8 mode);
void OLED_ShowChar6x8(u8 x,u8 y,u8 chr,u8 mode);
void OLED_ShowString(u8 x,u8 y,u8 *chr,u8 size1,u8 mode);
void OLED_ShowNum(u8 x,u8 y,u32 num,u8 len,u8 size1,u8 mode);
void OLED_ShowFloat(u8 x, u8 y, float num, u8 int_len, u8 frac_len, u8 size1, u8 mode);
void OLED_Init(void);

#endif

