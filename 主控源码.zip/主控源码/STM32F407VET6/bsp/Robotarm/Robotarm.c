#include "Robotarm.h"
#include "bsp_uart.h"
#include <string.h>

float MAX_y1=1940,MIN_y1=0;
float MAX_y2=1680,MIN_y2=0;
float MAX_y3=1020,MIN_y3=-980;
float MAX_j1=700,MIN_j1=0;

static uint8_t txBuffer3[16];  		// ���ͻ�����
static uint8_t txIndex3 = 0;    	// ��ǰ����λ��
static uint8_t txLength3 = 0;   	// �����ݳ���

/******************************************************************
���������
******************************************************************/
void usart3_SendCmd(uint8_t* cmd, uint8_t len)
{
    // �������ݵ����ͻ�����
    memcpy(txBuffer3, cmd, len);
    txIndex3 = 0;
    txLength3 = len;
    // ʹ�ܷ����ж�
    USART_ITConfig(USART3, USART_IT_TXE, ENABLE);
}
/************************************************uint8_t a[]={ 0x01,0xfd }
��е�۲���������ڷ���λ��-�ٶ�-���ٶ����ݰ�
*************************************************/
void Emm_V5_Pos_Control(uint8_t addr, uint8_t dir, uint16_t vel, uint8_t acc, uint32_t clk, bool raF, bool snF)
{
  uint8_t cmd[16] = {0};

  cmd[0]  =  addr;
  cmd[1]  =  0xFD;
  cmd[2]  =  dir;
  cmd[3]  =  (uint8_t)(vel >> 8);
  cmd[4]  =  (uint8_t)(vel >> 0);
  cmd[5]  =  acc;
  cmd[6]  =  (uint8_t)(clk >> 24);
  cmd[7]  =  (uint8_t)(clk >> 16);
  cmd[8]  =  (uint8_t)(clk >> 8);
  cmd[9]  =  (uint8_t)(clk >> 0);
  cmd[10] =  raF;
  cmd[11] =  snF;
  cmd[12] =  0x6B;

  usart3_SendCmd(cmd, 13);
}
/******************************************************************
����3�жϽ��պͷ���
******************************************************************/
void USART3_IRQHandler(void)
{
	if(USART_GetITStatus(USART3, USART_IT_RXNE) == SET)
	{
		uint8_t data = USART_ReceiveData(USART3);
		USART_ClearITPendingBit(USART3, USART_IT_RXNE);
	}
	else if (USART_GetITStatus(USART3, USART_IT_TXE) == SET)
	{
        if(txIndex3 < txLength3)
		{
            USART_SendData(USART3, txBuffer3[txIndex3++]);
        } else 
		{
            USART_ITConfig(USART3, USART_IT_TXE, DISABLE);
        }
        USART_ClearITPendingBit(USART3, USART_IT_TXE);
    }
}
/************************************************
��е�۶����ʼ��(��ۡ��б�)
*************************************************/
void Robotarm1_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5|GPIO_Pin_6;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOE, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOE,GPIO_PinSource5,GPIO_AF_TIM9); 
	GPIO_PinAFConfig(GPIOE,GPIO_PinSource6,GPIO_AF_TIM9);
	
	TIM_TimeBaseStructure.TIM_Period = arr;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM9, &TIM_TimeBaseStructure); 

 	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;   
	
	TIM_OC1Init(TIM9, &TIM_OCInitStructure); 
	TIM_OC2Init(TIM9, &TIM_OCInitStructure); 
	
	TIM_OC1PreloadConfig(TIM9, TIM_OCPreload_Enable);
	TIM_OC2PreloadConfig(TIM9, TIM_OCPreload_Enable);
	
	TIM_CtrlPWMOutputs(TIM9,ENABLE);

	TIM_Cmd(TIM9, ENABLE);
}
/************************************************
��е�۶����ʼ��(С��)
*************************************************/
void Robotarm2_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource9,GPIO_AF_TIM11); 
	
	TIM_TimeBaseStructure.TIM_Period = arr;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM11, &TIM_TimeBaseStructure); 

 	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;   
	
	TIM_OC1Init(TIM11, &TIM_OCInitStructure); 
	
	TIM_OC1PreloadConfig(TIM11, TIM_OCPreload_Enable);

	TIM_CtrlPWMOutputs(TIM11,ENABLE);
	
	TIM_Cmd(TIM11, ENABLE);
}
/************************************************
��е�۶����ʼ��(��צ)
*************************************************/
void Robotarm3_Init(u16 arr,u16 psc)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10,ENABLE);
	RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);

	GPIO_InitStructure.GPIO_Mode=GPIO_Mode_AF;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;
	GPIO_InitStructure.GPIO_Speed=GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_OType=GPIO_OType_PP;
	GPIO_InitStructure.GPIO_PuPd=GPIO_PuPd_UP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	GPIO_PinAFConfig(GPIOB,GPIO_PinSource8,GPIO_AF_TIM10); 
	
	TIM_TimeBaseStructure.TIM_Period = arr;
	TIM_TimeBaseStructure.TIM_Prescaler = psc;
	TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1; 
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; 
	TIM_TimeBaseInit(TIM10, &TIM_TimeBaseStructure); 

 	TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1; 
	TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; 
	TIM_OCInitStructure.TIM_Pulse = 0; 
	TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;   
	TIM_OCInitStructure.TIM_OCIdleState = TIM_OCIdleState_Reset;   
	
	TIM_OC1Init(TIM10, &TIM_OCInitStructure); 
	
	TIM_OC1PreloadConfig(TIM10, TIM_OCPreload_Enable);

	TIM_CtrlPWMOutputs(TIM10,ENABLE);
	
	TIM_Cmd(TIM10, ENABLE);
}
/************************************************
��е�۶��PWM�޷�
*************************************************/
void Robotarm_servo_limit(float *y1,float *y2,float *y3,float *j1)
{
	if(*y1>MAX_y1)*y1=MAX_y1;
	if(*y1<MIN_y1)*y1=MIN_y1;
	
	if(*y2>MAX_y2)*y2=MAX_y2;
	if(*y2<MIN_y2)*y2=MIN_y2;
	
	if(*y3>MAX_y3)*y3=MAX_y3;
	if(*y3<MIN_y3)*y3=MIN_y3;
	
	if(*j1>MAX_j1)*j1=MAX_j1;
	if(*j1<MIN_j1)*j1=MIN_j1;
}
