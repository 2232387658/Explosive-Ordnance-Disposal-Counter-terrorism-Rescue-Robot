#ifndef __ROBOTARM_H__
#define __ROBOTARM_H__

#include "stm32f4xx.h"
#include <stdbool.h>

void Emm_V5_Pos_Control(uint8_t addr, uint8_t dir, uint16_t vel, uint8_t acc, uint32_t clk, bool raF, bool snF);
void usart3_SendCmd(uint8_t* cmd, uint8_t len);
void Robotarm1_Init(u16 arr,u16 psc);
void Robotarm2_Init(u16 arr,u16 psc);
void Robotarm3_Init(u16 arr,u16 psc);
void Robotarm_servo_limit(float *y1,float *y2,float *y3,float *j1);

#endif
