#ifndef __LASER_H__
#define __LASER_H__

#include "stm32f4xx.h"

void laser_Init(void);
void laser_servo_Init(u16 arr,u16 psc);

#endif
