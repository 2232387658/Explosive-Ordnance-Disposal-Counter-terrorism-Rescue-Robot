#include "adc.h"

/******************************************************************
adc��ʼ��
******************************************************************/
void adc_Init(void)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	
	ADC_CommonInitTypeDef ADC_CommonInitStruct;
	ADC_InitTypeDef ADC_InitStruct;

	RCC_AHB1PeriphClockCmd (RCC_V_GPIO, ENABLE);
	RCC_APB2PeriphClockCmd(RCU_V_ADC, ENABLE);

	GPIO_InitStructure.GPIO_Pin = GPIO_V_O|GPIO_V_2;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_100MHz;
	GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL;
	GPIO_Init(PORT_V, &GPIO_InitStructure);


	ADC_CommonInitStruct.ADC_DMAAccessMode=ADC_DMAAccessMode_Disabled;
	ADC_CommonInitStruct.ADC_Mode=ADC_Mode_Independent;
	ADC_CommonInitStruct.ADC_Prescaler=ADC_Prescaler_Div4;
	ADC_CommonInitStruct.ADC_TwoSamplingDelay=ADC_TwoSamplingDelay_5Cycles;

	ADC_CommonInit(&ADC_CommonInitStruct);

	ADC_InitStruct.ADC_ContinuousConvMode = DISABLE;
	ADC_InitStruct.ADC_DataAlign=ADC_DataAlign_Right;
	ADC_InitStruct.ADC_ExternalTrigConvEdge=ADC_ExternalTrigConvEdge_None;
	ADC_InitStruct.ADC_NbrOfConversion=2;
	ADC_InitStruct.ADC_Resolution=ADC_Resolution_12b;
	ADC_InitStruct.ADC_ScanConvMode = ENABLE;

	ADC_Init(PORT_ADC, &ADC_InitStruct);

	ADC_Cmd(PORT_ADC, ENABLE);
}
/******************************************************************
��ȡadcֵ
******************************************************************/
unsigned int Get_adc_Value0(char CHx)
{
	unsigned char i = 0;
	unsigned int AdcValue = 0;

	ADC_RegularChannelConfig(PORT_ADC, CHx,2, ADC_SampleTime_84Cycles );

	ADC_SoftwareStartConv(PORT_ADC);

	for(i=0; i< SAMPLES; i++)
	{
		AdcValue += ADC_GetConversionValue(PORT_ADC);
	}
	
	AdcValue = AdcValue / SAMPLES;

	return AdcValue;
}
unsigned int Get_adc_Value2(char CHx)
{
	unsigned char i = 0;
	unsigned int AdcValue = 0;

	ADC_RegularChannelConfig(PORT_ADC, CHx, 1, ADC_SampleTime_84Cycles );

	ADC_SoftwareStartConv(PORT_ADC);

	for(i=0; i< SAMPLES; i++)
	{
		AdcValue += ADC_GetConversionValue(PORT_ADC);
	}
	
	AdcValue = AdcValue / SAMPLES;

	return AdcValue;
}
/******************************************************************
��ȡС�������ٷֱ�
******************************************************************/
float Get_V_value0(void)
{
    int adc_max = 4095;
    int adc_new = 0;
    float Percentage_value = 0;

    adc_new = Get_adc_Value0(CHANNEL_ADC0);

    Percentage_value = (adc_new* 3.3f*10/adc_max) *100/12.6f;
	
    return Percentage_value;
}
/******************************************************************
��ȡ��е�۵����ٷֱ�
******************************************************************/
float Get_V_value2(void)
{
    int adc_max = 4095;
    int adc_new = 0;
    float Percentage_value = 0;

    adc_new = Get_adc_Value2(CHANNEL_ADC2);

    Percentage_value = (adc_new* 3.3f*10/adc_max) *100/12.6f;
	
    return Percentage_value;
}
