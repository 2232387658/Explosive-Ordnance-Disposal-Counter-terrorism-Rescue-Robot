#ifndef __ADC_H__
#define __ADC_H__

#include "stm32f4xx.h"

#define RCC_V_GPIO        RCC_AHB1Periph_GPIOC
#define RCU_V_ADC         RCC_APB2Periph_ADC1

#define PORT_ADC          ADC1
#define CHANNEL_ADC0      ADC_Channel_10
#define CHANNEL_ADC2      ADC_Channel_12

#define PORT_V        	  GPIOC
#define GPIO_V_O          GPIO_Pin_0
#define GPIO_V_2          GPIO_Pin_2

#define SAMPLES           30

void adc_Init(void);
unsigned int Get_adc_Value0(char CHx);
unsigned int Get_adc_Value2(char CHx);
float Get_V_value0(void);
float Get_V_value2(void);

#endif
