#ifndef __BOARD_H__
#define __BOARD_H__

#include "stm32f4xx.h"

void board_Init(void);
void delay_us(uint32_t _us);
void delay_ms(uint32_t _ms);
void delay_s(uint32_t _s);
void NVIC_Configuration(void);

#endif
