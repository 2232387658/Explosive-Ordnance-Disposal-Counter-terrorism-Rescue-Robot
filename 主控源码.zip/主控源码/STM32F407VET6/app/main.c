#include "board.h"
#include "key.h"//PE2/PE3/PE4
#include "buzzer.h"//PE15
#include "adc.h"//PC1/PC2
#include "hwt101.h"//PB10/PB13
#include "encoder.h"//PB4/PB5(TIM3),PD12/D13(TIM4),PD12/D13(TIM5),PD12/D13(TIM2)
#include "bsp_uart.h"//PB6/PB7(����1),PD5/PD6(����2),PD8/PD9(����3),PD2/PC12(����5),PC6/PC7(����6)
#include "oled.h"//PB11/PB12
#include "timer.h"//(TIM7��TIM6��TIM8��TIM14)
#include "moto.h"//PE9/PE11/PE13/PE14(PWM),PD10/PD11/PD14/PD15/PE7/PE8/PE10/PE12(����)
#include "laser.h"//PE0/PE1,PB8(TIM10)
#include "Robotarm.h"//PE5/PE6(TIM9),PB14/PB15(TIM12)��PB9(TIM11),PA6(TIM13)(��е��)

#include <stdio.h>
#include <math.h>
int jjjj=0;
int o=0,q=0,xx=0,guang=0,ma_sf=0,ma_sl=0,ma_sr=0,mm=0,abc=0,bobo=1,baba=1,maixcam=1;
int qiu_y=0,qiu_y_flag=0;
int jiansudai_flag=0,jiansudai_sl=0,jiansudai_sr=0,w=0;
int renzhi_sr=0,renzhi_sl=0,renzhi_sr0=0,renzhi_sl0=0,renzhi_flag=0,juli_flag=0,yuanzhu_flag=0,yuantai_flag=0,yaogu_flag=0,zhongdian=0,zhongdian_flag=0,dd=0,ee=0,ff=0;
int qiu_sl=0,qiu_sr=0,qiu_sl0=0,qiu_sr0=0,qiu_flag=0,hong_flag=1,lv_flag=1,lan_flag=1,aa=0,bb=0,cc=0,juli=0,fangxiang=0;
float Servo_y1_PWM=0,Servo_y2_PWM=0,Servo_y3_PWM=0,Servo_j1_PWM=0,Servo_m1_PWM=0;
float way_long=0,angle_big=0;
int t_flag=0,t=-1,time_inter=0,time_temp=0;
int s_flag=0;
int a=0,a1=0,a2=0,a3=0,a4=0,a5=0,a6=0,a7=0,a8=0,a9=0,a10=0,a11=0,a12=0,a13=0,a14=0,a15=0,a16=0,a17=0,a18=0,a19=0,a20=0,a21=0,a22=0,a23=0,a24=0,a25=0,a26=0,a27=0,a28=0,a29=0,a30=0,a31=0;
int Maixcam_data1=0,Maixcam_data2=0,Maixcam_data3=0,Maixcam_data4=0;
int OpenMV_data1=0,OpenMV_data2=0,OpenMV_data3=0,OpenMV_data4=0,OpenMV_data5=0,OpenMV_data6=0,OpenMV_data7=0,OpenMV_data8=0,OpenMV_data9=0;
float V0=0,V2=0;
int encoder_LU_speed=0,encoder_RU_speed=0;
int MOTOLU=0,MOTOLD=0,MOTORU=0,MOTORD=0;
int Moto_LU_dingwei=0,Moto_RU_dingwei=0,Angle_PWM=0,Moto_zitai=0;
int bujin=0,duoji=0,arm_flag=0;
int saoma=0,saoma_flag=0,mv_flag=0,ma_flag=0;
int clear=0,tt=0,hjh=0,time=0;
float te=0;
int wwww=0;
int fengmingqi=1,chushi=1;
uint8_t reset_z_axis[] = {0xFF, 0xAA, 0x76, 0x00, 0x00};//HWT101ƫ���ǹ���ͨ��Э�����ݰ�
uint8_t save_settings[] = {0xFF, 0xAA, 0x00, 0x00, 0x00};//HWT101��������ͨ��Э�����ݰ�
uint8_t unlock_register[] = {0xFF, 0xAA, 0x69, 0x88, 0xB5};//HWT101�������ͨ��Э�����ݰ�

int main(void)
{
	NVIC_Configuration();			//���ȼ�����
	board_Init();					//��ʱ��ʼ��
	adc_Init();						//����
	moto_Init(1000-1,168-1);		//С��ֱ�����
	Robotarm1_Init(10000-1,168-1);	//��е�۶��(����б�)
	Robotarm2_Init(10000-1,168-1);	//��е�۶��(С��)
	Robotarm3_Init(10000-1,168-1);	//��е�۶��(��צ)
	laser_servo_Init(10000-1,84-1); //��׼�����
	OLED_Init();					//OLED
	OLED_Clear();					//����
	encoder_TIM4_Init();			//���ϱ�����
	encoder_TIM5_Init();			//���ϱ�����
	laser_Init();					//�켤��
	buzzer_Init();					//������
	key_Init();						//����
	usart3_Init(115200U);			//��е�۲������
	usart2_Init(115200U);			//��е�۲������
	usart1_Init(115200U);			//��е�۲������
	usart6_Init(115200U);			//��е�۲������
	delay_ms(1000);
	uart4_Init(115200U);			//��е�۲������
	TIM7_Init(1000-1,84-1);			//��ʱ��7(���ݶ�ȡ)
	TIM6_Init(1000-1,84-1);			//��ʱ��6(С������)
	TIM2_Init(1000-1,8400-1);
	TIM3_Init(1000-1,84-1);
	delay_ms(1000);
	if(chushi==1)
	{
		Emm_V5_Pos_Control(1, 0, 20, 20, 90, 0, 0);
		chushi=0;
	}
	delay_ms(2000);
	Uart4_SendArray(unlock_register, sizeof(unlock_register));
	Uart4_SendArray(reset_z_axis, sizeof(reset_z_axis));
	Uart4_SendArray(save_settings, sizeof(save_settings));
   	while(1)
	{
		key_add();					//������
		key_subtract();				//������
		key_sure();					//����ȷ��
		erro_check();				//������ʾ
		if(key_count==0)//����������
		{
			if(sure==1)
			{
				time=1;
				saoma=1;
				a=1;
				a1=1;
				clear=1;
				sure=0;
			}
		}
		else if(key_count==1)//��ά��ʶ�����
		{
			if(sure==1)
			{
				duoji=13;
				sure=0;
			}
		}
		else if(key_count==2)//���ٴ�
		{
			if(sure==1)
			{
				a=1;
				a7=1;
				t=4;
				hjh=1;
				clear=1;
				sure=0;
			}
		}
		else if(key_count==3)//�ű���ʶ�����
		{
			if(sure==1)
			{
				bujin=2;
				duoji=1;
				sure=0;
			}
		}
		else if(key_count==4)//���ְ�ʶ�����
		{
			if(sure==1)
			{
				GPIO_ResetBits(GPIOE, GPIO_Pin_0);
				sure=0;
			}
		}
		else if(key_count==5)//����ʶ�����
		{
			if(sure==1)
			{
				USART1_SendByte(0x01);
				bujin=2;
				duoji=11;
				sure=0;
			}
		}
		if(saoma==1)//ɨ��
		{
			duoji=13;
			saoma_flag=1;
		}
		if(saoma_flag==1)//��ȡ����
		{
			if(OpenMV_data1==1&&OpenMV_data2==1&&OpenMV_data3==1)
			{
				saoma=0;
				qiu_flag=1;
				ma_flag=1;
				renzhi_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==1&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=1;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==1&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=1;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==2&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=2;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==2&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=2;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==2&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=2;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==3&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=3;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==3&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=3;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==1&&OpenMV_data2==3&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=3;
				qiu_flag=1;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==1&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=1;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==1&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=1;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==1&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=1;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==2&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=2;
				qiu_flag=2;
				clear=1;
				duoji=14; 
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==2&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=2;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==2&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=2;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==3&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=3;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==3&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=3;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==2&&OpenMV_data2==3&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=3;
				qiu_flag=2;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==1&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=1;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==1&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=1;
				qiu_flag=3; 
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==1&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=1;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==2&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=2;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==2&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=2;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==2&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=2;
				qiu_flag=3;
				clear=1; 
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==3&&OpenMV_data3==1)
			{
				saoma=0;
				renzhi_flag=1;
				ma_flag=3;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==3&&OpenMV_data3==2)
			{
				saoma=0;
				renzhi_flag=2;
				ma_flag=3;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
			else if(OpenMV_data1==3&&OpenMV_data2==3&&OpenMV_data3==3)
			{
				saoma=0;
				renzhi_flag=3;
				ma_flag=3;
				qiu_flag=3;
				clear=1;
				duoji=14;
				wwww=1;
			}
		}
		if(bujin==100)
		{
			Emm_V5_Pos_Control(1, 0, 20, 20, 610, 0, 0);
			bujin=0;
		}
		else if(bujin==2)
		{
			Emm_V5_Pos_Control(1, 1, 20, 20, 610, 0, 0);
			bujin=0;
		}
		else if(bujin==3)
		{
			Emm_V5_Pos_Control(1, 1, 20, 20, 1294, 0, 0);
			bujin=0;
		}
		else if(bujin==5)
		{
			Emm_V5_Pos_Control(1, 1, 20, 20, 1616, 0, 0);
			bujin=0;
		}
		else if(bujin==6)
		{
			Emm_V5_Pos_Control(1, 1, 20, 20, 1928, 0, 0);
			bujin=0;
		}
		else if(bujin==4)
		{
			Emm_V5_Pos_Control(1, 0, 20, 20, 1904, 0, 0);
			bujin=0;
		}
		else if(bujin==7)
		{
			Emm_V5_Pos_Control(1, 0, 20, 20, 2226, 0, 0);
			bujin=0;
		}
		else if(bujin==8)
		{
			Emm_V5_Pos_Control(1, 0, 20, 20, 2538, 0, 0);
			bujin=0;
		}
		if(a==1)
		{
			if(a1==1)//��һ��ֱ��580mm
			{
				s_time=0.01;
				angle_big=0;//Ŀ��Ƕ�0��
				if(clear==1)
				{
					Integral_bias1=0;
					Integral_bias2=0;
					clear=0;
				}
				if(Total_Distance_LU>=0&&Total_Distance_LU<475&&Total_Distance_RU>=0&&Total_Distance_RU<475)
				{
					MOTOLU=-Moto_zitai+240;
					MOTOLD=-Moto_zitai+240;
					MOTORU=-Moto_zitai-240;
					MOTORD=-Moto_zitai-240;
				}
				else if(Total_Distance_LU>=475&&Total_Distance_LU<505&&Total_Distance_RU>=475&&Total_Distance_RU<505)
				{
					MOTOLU=-Moto_zitai+210;
					MOTOLD=-Moto_zitai+210;
					MOTORU=-Moto_zitai-210;
					MOTORD=-Moto_zitai-210;
				}
				else if(Total_Distance_LU>=505&&Total_Distance_LU<535&&Total_Distance_RU>=505&&Total_Distance_RU<535)
				{
					MOTOLU=-Moto_zitai+150;
					MOTOLD=-Moto_zitai+150;
					MOTORU=-Moto_zitai-150;
					MOTORD=-Moto_zitai-150;
				}
				else if(Total_Distance_LU>=535&&Total_Distance_LU<565&&Total_Distance_RU>=535&&Total_Distance_RU<565)
				{
					MOTOLU=-Moto_zitai+60;
					MOTOLD=-Moto_zitai+60;
					MOTORU=-Moto_zitai-60;
					MOTORD=-Moto_zitai-60;
				}
				else if(Total_Distance_LU>=565&&Total_Distance_RU>=565)
				{
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
					t_flag=1;
					s_time=0;
					s_flag=1;
					tt=1;
					time_inter=1;
					a2=1;
				}
			}
			if(a2==1)//��һ��ֹͣ
			{
				a1=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a3=1;
			}
			if(a3==1)//��һ����ת90��0.8s
			{
				if(wwww==1)
				{
					if(t==1)
					{
						saoma_flag=0;
						a2=0;
						time_inter=6;
						angle_big=90;//Ŀ��Ƕ�90��
						MOTOLU=-Moto_zitai*0.2;
						MOTOLD=-Moto_zitai*0.2;
						MOTORU=-Moto_zitai*1.1;
						MOTORD=-Moto_zitai*1.1;
						if(global_angle>=89&&global_angle<=91)
						{
							if(tt==1)
							{
								t_flag=1;
								clear=1;
								tt=0;
							}
						}
						if(s_flag==1)
						{
							Total_Distance_LU=0;
							Total_Distance_RU=0;
							s_flag=0;
						}
						if(t_flag==1)
						{
							TIM_Cmd(TIM2,ENABLE);
							t_flag=0;
						}
						a4=1;
					}
				}
			}
			if(a4==1)//�ڶ���ֱ��515mm
			{
				if(t==2)
				{
					a3=0;
					s_time=0.01;
					angle_big=90;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<410&&Total_Distance_RU>=0&&Total_Distance_RU<410)
					{
						MOTOLU=-Moto_zitai+240;
						MOTOLD=-Moto_zitai+240;
						MOTORU=-Moto_zitai-240;
						MOTORD=-Moto_zitai-240;
					}
					else if(Total_Distance_LU>=410&&Total_Distance_LU<440&&Total_Distance_RU>=410&&Total_Distance_RU<440)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=440&&Total_Distance_LU<470&&Total_Distance_RU>=440&&Total_Distance_RU<470)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=470&&Total_Distance_LU<500&&Total_Distance_RU>=470&&Total_Distance_RU<500)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					else if(Total_Distance_LU>=500&&Total_Distance_RU>=500)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						time_inter=1;
						s_time=0;
						s_flag=1;
						tt=1;
						a5=1;
					}
				}
			}
			if(a5==1)
			{
				a4=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a6=1;
			}
			if(a6==1)
			{
				if(t==3)
				{
					a5=0;
					time_inter=6;
					angle_big=0;
					MOTOLU=-Moto_zitai*1.12;
					MOTOLD=-Moto_zitai*1.12;
					MOTORU=-Moto_zitai*0.18;
					MOTORD=-Moto_zitai*0.18;
					if(global_angle>=-1&&global_angle<=1)
					{
						if(tt==1)
						{
							t_flag=1;
							clear=1;
							abc=1;
							tt=0;
						}
					}
					if(s_flag==1)
					{
						Total_Distance_LU=0;
						Total_Distance_RU=0;
						s_flag=0;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
				    a7=1;
				}
			}
			if(a7==1)
			{
				if(t==4)
				{
					a6=0;
					s_time=0.01;
					angle_big=0;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<100&&Total_Distance_RU>=0&&Total_Distance_RU<100)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=100&&Total_Distance_LU<130&&Total_Distance_RU>=100&&Total_Distance_RU<130)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150; 
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=130&&Total_Distance_LU<750&&Total_Distance_RU>=130&&Total_Distance_RU<750)
					{
						if(encoder_LU_speed==0&&encoder_RU_speed==0)
						{
							MOTOLU=-Moto_zitai+290;
							MOTOLD=-Moto_zitai+290;
							MOTORU=-Moto_zitai-290;
							MOTORD=-Moto_zitai-290;
						}
						else if(encoder_LU_speed!=0&&encoder_RU_speed!=0)
						{
							MOTOLU=-Moto_zitai+100;
							MOTOLD=-Moto_zitai+100;
							MOTORU=-Moto_zitai-100;
							MOTORD=-Moto_zitai-100;
						}
					}
					else if(Total_Distance_LU>=750&&Total_Distance_RU>=750)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						clear=1;
						time_inter=1;
						s_flag=1;
						s_time=0;
						a8=1;
					}
				}
			}
			if(a8==1)
			{
				a7=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(s_flag==1)
				{
					Total_Distance_LU=0;
					Total_Distance_RU=0;
					s_flag=0;
				}
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a9=1;
			}
			if(a9==1)
			{
				if(t==5)
				{
					a8=0;
					s_time=0.01;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU<=0&&Total_Distance_LU>-20&&Total_Distance_RU<=0&&Total_Distance_RU>-20)
					{
						MOTOLU=-Moto_zitai-210;
						MOTOLD=-Moto_zitai-210;
						MOTORU=-Moto_zitai+210;
						MOTORD=-Moto_zitai+210;
					}
					else if(Total_Distance_LU<=-20&&Total_Distance_LU>-60&&Total_Distance_RU<=-20&&Total_Distance_RU>-60)
					{
						MOTOLU=-Moto_zitai-150;
						MOTOLD=-Moto_zitai-150;
						MOTORU=-Moto_zitai+150;
						MOTORD=-Moto_zitai+150;
					}
					else if(Total_Distance_LU<=-60&&Total_Distance_RU<=-60)
					{
						if(encoder_LU_speed==0&&encoder_RU_speed==0)
						{
							MOTOLU=-Moto_zitai;
							MOTOLD=-Moto_zitai;
							MOTORU=-Moto_zitai;
							MOTORD=-Moto_zitai;
							clear=1;
							t_flag=1;
							time_inter=1;//������ʱ
							s_flag=1;
							s_time=0;//���üƲ�
							a10=1;//������һ��
						}
						else if(encoder_LU_speed!=0&&encoder_RU_speed!=0)
						{
							MOTOLU=-Moto_zitai-60;
							MOTOLD=-Moto_zitai-60;
							MOTORU=-Moto_zitai+60;
							MOTORD=-Moto_zitai+60;
						}
					}
				}
			}
			if(a10==1)
			{
				a9=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(s_flag==1)
				{
					Total_Distance_LU=0;
					Total_Distance_RU=0;
					s_flag=0;
				}
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a11=1;
			}
			if(a11==1)
			{
				if(t==6)
				{
					a10=0;
					s_time=0.01;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<75&&Total_Distance_RU>=0&&Total_Distance_RU<75)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=75&&Total_Distance_LU<105&&Total_Distance_RU>=75&&Total_Distance_RU<105)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=105&&Total_Distance_LU<135&&Total_Distance_RU>=105&&Total_Distance_RU<135)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					else if(Total_Distance_LU>=135&&Total_Distance_RU>=135)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						s_time=0;
						s_flag=1;
						time_inter=1;//������ʱ
						tt=1;
						a12=1;
					}
				}
			}
			if(a12==1)//������ֱ���յ�ֹͣ0.1s
			{
				a11=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				if(hjh==0)
				{
					a13=1;
				}
				else if(hjh==1)
				{
					a13=0;
				}
			}
			if(a13==1)//��������ת90��2.5s
			{
				if(t==7)
				{
					a12=0;
					time_inter=6;
					angle_big=90;
					MOTOLU=-Moto_zitai*0.2;
					MOTOLD=-Moto_zitai*0.2;
					MOTORU=-Moto_zitai*1.1;
					MOTORD=-Moto_zitai*1.1;
					if(global_angle>=89&&global_angle<=91)
					{
						if(tt==1)
						{
							t_flag=1;
							clear=1;
							tt=0;
						}
					}
					if(s_flag==1)
					{
						Total_Distance_LU=0;
						Total_Distance_RU=0;
						s_flag=0;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					a14=1;
				}
			}
			if(a14==1)
			{
				if(t==8)
				{
					a13=0;
					s_time=0.01;
					angle_big=90;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<550&&Total_Distance_RU>=0&&Total_Distance_RU<550)
					{
						MOTOLU=-Moto_zitai+240;
						MOTOLD=-Moto_zitai+240;
						MOTORU=-Moto_zitai-240;
						MOTORD=-Moto_zitai-240;
					}
					else if(Total_Distance_LU>=550&&Total_Distance_LU<580&&Total_Distance_RU>=550&&Total_Distance_RU<580)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=580&&Total_Distance_LU<610&&Total_Distance_RU>=580&&Total_Distance_RU<610)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=610&&Total_Distance_LU<680&&Total_Distance_RU>=610&&Total_Distance_RU<680)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					else if(Total_Distance_LU>=680&&Total_Distance_RU>=680)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						s_time=0;
				        s_flag=1;
						time_inter=1;
						tt=1;
						a15=1;
					}
				}
			}
			if(a15==1)//���Ķ�ֱ���յ�ֹͣ0.1s
			{
				a14=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a16=1;
			}
			if(a16==1)//���Ķ�ֱ���յ���ת90��ʱ��3s
			{
				if(t==9)
				{
					a15=0;
					time_inter=6;
					angle_big=0;
					MOTOLU=-Moto_zitai*1.12;
					MOTOLD=-Moto_zitai*1.12;
					MOTORU=-Moto_zitai*0.18;
					MOTORD=-Moto_zitai*0.18;
					if(global_angle>=-1&&global_angle<=1)
					{
						if(tt==1)
						{
							t_flag=1;
							clear=1;
							tt=0;
						}
					}
					if(s_flag==1)
					{
						Total_Distance_LU=0;
						Total_Distance_RU=0;
						s_flag=0;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					a17=1;
				}
			}
			if(a17==1)//�����ֱ��795mm
			{
				if(t==10)
				{
					a16=0;
					s_time=0.01;
					angle_big=0;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<710&&Total_Distance_RU>=0&&Total_Distance_RU<710)
					{
						MOTOLU=-Moto_zitai+240;
						MOTOLD=-Moto_zitai+240;
						MOTORU=-Moto_zitai-240;
						MOTORD=-Moto_zitai-240;
					}
					else if(Total_Distance_LU>=710&&Total_Distance_LU<740&&Total_Distance_RU>=710&&Total_Distance_RU<740)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=740&&Total_Distance_LU<770&&Total_Distance_RU>=740&&Total_Distance_RU<770)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=770&&Total_Distance_LU<830&&Total_Distance_RU>=770&&Total_Distance_RU<830)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					else if(Total_Distance_LU>=830&&Total_Distance_RU>=830)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						s_time=0;
						s_flag=1;
						time_inter=1;
						tt=1;
						a18=1;
					}
				}
			}
			if(a18==1)//�����ֱ���յ�ֹͣ0.2s
			{
				a17=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a19=1;
			}
			if(a19==1)//�������ת90��2.5s
			{
				if(t==11)
				{
					a18=0;
					time_inter=6;
					angle_big=-90;
					MOTOLU=-Moto_zitai*1.12;
					MOTOLD=-Moto_zitai*1.12;
					MOTORU=-Moto_zitai*0.18;
					MOTORD=-Moto_zitai*0.18;
					if(s_flag==1)
					{
						Total_Distance_LU=0;
						Total_Distance_RU=0;
						s_flag=0;
					}
					if(global_angle>=-91&&global_angle<=-89)
					{
						if(tt==1)
						{
							
							clear=1;
							mv_flag=1;
							arm_flag=1;
							hong_flag=1;
							lv_flag=1;
							lan_flag=1;
							juli_flag=1;
							qiu_y_flag=1;
							t_flag=1;
							tt=0;
						}
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					a20=1;
				}
			}
			if(a20==1)//������ֱ��ʶ���ű���
			{
				if(t==12)
				{
					a19=0;
					s_time=0.01;
					angle_big=-90;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<150&&Total_Distance_RU>=0&&Total_Distance_RU<150)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=150&&Total_Distance_LU<390&&Total_Distance_RU>=150&&Total_Distance_RU<390)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
						if(arm_flag==1)
						{
							duoji=1;
							bujin=2;
							arm_flag=0;
						}
					}
					else if(Total_Distance_LU>=390&&Total_Distance_LU<420&&Total_Distance_RU>=390&&Total_Distance_RU<420)
					{
						MOTOLU=-Moto_zitai+135;
						MOTOLD=-Moto_zitai+135;
						MOTORU=-Moto_zitai-135;
						MOTORD=-Moto_zitai-135;
						if(bobo==1)
						{
							OpenMV_data4=0;
							OpenMV_data5=0;
							OpenMV_data6=0;
							OpenMV_data7=0;
							OpenMV_data8=0;
							OpenMV_data9=0;
							bobo=0;
						}
					}
					else if(Total_Distance_LU>=420&&Total_Distance_RU>=420)
					{
						if(OpenMV_data4>=162&&OpenMV_data4<=193)//����
						{
							if(hong_flag==1)
							{
								aa=Total_Distance_LU;
								hong_flag=0;
							}
						}
						if(OpenMV_data5>=162&&OpenMV_data5<=193)//����
						{
							if(lv_flag==1)
							{
								bb=Total_Distance_LU;
								lv_flag=0;
							}
						}
						if(OpenMV_data6>=162&&OpenMV_data6<=193)//����
						{
							if(lan_flag==1)
							{
								cc=Total_Distance_LU;
								lan_flag=0;
							}
						}
						if(qiu_flag==1)//����
						{
							if(OpenMV_data4>=162&&OpenMV_data4<=193)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(bb==0&&cc==0)
								{
									juli=1;
									fangxiang=1;
								}
								else if((aa>bb&&cc==0)||(aa>cc&&bb==0))
								{
									juli=2;
									fangxiang=2;
								}
								else if(aa>cc&&aa>bb&&cc!=0&&bb!=0)
								{
									juli=3;
									fangxiang=3;
								}
								if(qiu_y_flag==1)
								{
									qiu_y=OpenMV_data7;
									qiu_y_flag=0;
								}
								t_flag=1;
								s_time=0;
								s_flag=1;
								tt=1;
								arm_flag=2;
								time_inter=1;
								a21=1;
							}
							else if(OpenMV_data4==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(qiu_flag==2)//����
						{
							if(OpenMV_data5>=162&&OpenMV_data5<=193)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(aa==0&&cc==0)
								{
									juli=1;
									fangxiang=1;
								}
								else if((bb>aa&&cc==0)||(bb>cc&&aa==0))
								{
									juli=2;
									fangxiang=2;
								}
								else if(bb>aa&&bb>cc&&cc!=0&&aa!=0)
								{	
									juli=3;
									fangxiang=3;
								}
								if(qiu_y_flag==1)
								{
									qiu_y=OpenMV_data8;
									qiu_y_flag=0;
								}
								t_flag=1;
								s_time=0;
								s_flag=1;
								tt=1;
								arm_flag=2;
								time_inter=1;
								a21=1;
							}
							else if(OpenMV_data5==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(qiu_flag==3)//����
						{
							if(OpenMV_data6>=162&&OpenMV_data6<=193)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(bb==0&&aa==0)
								{
									juli=1;
									fangxiang=1;
								}
								else if((cc>bb&&aa==0)||(cc>aa&&bb==0))
								{
									juli=2;
									fangxiang=2;
								}
								else if(cc>bb&&cc>aa&&bb!=0&&aa!=0)
								{	
									juli=3;
									fangxiang=3;
								}
								if(qiu_y_flag==1)
								{
									qiu_y=OpenMV_data9;
									qiu_y_flag=0;
								}
								t_flag=1;
								s_time=0;
								s_flag=1;
								tt=1;
								arm_flag=2;
								time_inter=1;
								a21=1;
							}
							else if(OpenMV_data6==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						if(juli==1)
						{
							if(juli_flag==1)
							{
								qiu_sl0=Total_Distance_LU;
								qiu_sr0=Total_Distance_RU;
								qiu_sl=qiu_sl0+2370;
								qiu_sr=qiu_sr0+2370;
								juli_flag=0;
							}
						}
						else if(juli==2)
						{
							if(juli_flag==1)
							{
								qiu_sl0=Total_Distance_LU;
								qiu_sr0=Total_Distance_RU;
								qiu_sl=qiu_sl0+2220;
								qiu_sr=qiu_sr0+2220; 
								juli_flag=0;
							}
						}
						else if(juli==3)
						{
							if(juli_flag==1)
							{
								qiu_sl0=Total_Distance_LU;
								qiu_sr0=Total_Distance_RU;
								qiu_sl=qiu_sl0+2070;
								qiu_sr=qiu_sr0+2070;
								juli_flag=0;
							}
						}
					}
				}
			}
			if(a21==1)//������ֱ���ű���ֹͣ0.2s
			{
				a20=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a22=1;
			}
			if(a22==1)//������ֱ������ű�
			{
				
				if(t==13)
				{
					a21=0;
					time_inter=4;
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
					if(arm_flag==2)//��ȡ0.6s
					{
						duoji=2;
						arm_flag=0;
					}
					if(tt==1)
					{
						t_flag=1;
						tt=2;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
				}
				else if(t==14)
				{
					arm_flag=3;
					if(tt==2)
					{
						t_flag=1;
						tt=3;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==15)
				{
					if(juli==1)
					{
						time_inter=8;
					}
					else if(juli==2)
					{
						time_inter=10;
					}
					else if(juli==3)
					{
						time_inter=12;
					}
					if(arm_flag==3)
					{
						duoji=3;
						if(fangxiang==1)
						{
							bujin=3;
						}
						else if(fangxiang==2)
						{
							bujin=5;
						}
						else if(fangxiang==3)
						{
							bujin=6;
						}
						arm_flag=0;
					}
					if(tt==3)
					{
						t_flag=1;
						tt=4;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==16)
				{
					arm_flag=4;
					if(tt==4)
					{
						t_flag=1;
						tt=5;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==17)
				{
					time_inter=4;
					if(arm_flag==4)//�½�0.4s
					{
						if(juli==1)
						{
							duoji=4;
						}
						else if(juli==2)
						{
							duoji=7;
						}
						else if(juli==3)
						{
							duoji=4;
						}
						arm_flag=0;
					}
					if(tt==5)
					{
						t_flag=1;
						tt=6;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==18)
				{
					arm_flag=5;
					if(tt==6)
					{
						t_flag=1;
						tt=7;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==19)
				{
					time_inter=4;
					if(arm_flag==5)//����1s
					{
						duoji=5;
						arm_flag=6;
					}
					if(tt==7)
					{
						t_flag=1;
						tt=8;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					s_time=0.01;
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==20)
				{
					time_inter=8;
					if(arm_flag==6)
					{
						duoji=66;
						arm_flag=7;
					}
					if(tt==8)
					{
						t_flag=1;
						tt=9;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai+180;
					MOTOLD=-Moto_zitai+180;
					MOTORU=-Moto_zitai-180;
					MOTORD=-Moto_zitai-180;
				}
				else if(t==21)
				{
					if(juli==1)
					{
						time_inter=16;
					}
					else if(juli==2)
					{
						time_inter=20;
					}
					else if(juli==3)
					{
						time_inter=24;
					}
					if(arm_flag==7)
					{
						if(juli==1)
						{
							bujin=4;
						}
						else if(juli==2)
						{
							bujin=7;
						}
						else if(juli==3)
						{
							bujin=8;
						}
						arm_flag=8;
					}
					if(tt==9)
					{
						t_flag=1;
						tt=10;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai+180;
					MOTOLD=-Moto_zitai+180;
					MOTORU=-Moto_zitai-180;
					MOTORD=-Moto_zitai-180;
				}
				else if(t==22)
				{
					time_inter=6;
					if(arm_flag==8)//��ԭ1s
					{
						duoji=6;
						arm_flag=0;
					}
					if(tt==10)
					{
						t_flag=1;
						tt=11;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai+180;
					MOTOLD=-Moto_zitai+180;
					MOTORU=-Moto_zitai-180;
					MOTORD=-Moto_zitai-180;
					clear=1;
					a23=1;
				}
			}
			if(a23==1)//������ֱ��ʶ�𷴿ְ���ɷ���
			{
				if(t==23)
				{
					a22=0;
					guang=1;
					time_inter=2;
					if(tt==11)
					{
						t_flag=1;
						tt=12;
					}
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU<(qiu_sl-970)&&Total_Distance_RU<(qiu_sr-970))
					{
						MOTOLU=-Moto_zitai+240;
						MOTOLD=-Moto_zitai+240;
						MOTORU=-Moto_zitai-240;
						MOTORD=-Moto_zitai-240;
					}
					else if(Total_Distance_LU>=(qiu_sl-970)&&Total_Distance_LU<(qiu_sl-940)&&Total_Distance_RU>=(qiu_sr-970)&&Total_Distance_RU<(qiu_sr-940))
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=(qiu_sl-940)&&Total_Distance_LU<(qiu_sl-910)&&Total_Distance_RU>=(qiu_sr-940)&&Total_Distance_RU<(qiu_sr-910))
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=(qiu_sl-910)&&Total_Distance_LU<(qiu_sl-880)&&Total_Distance_RU>=(qiu_sr-910)&&Total_Distance_RU<(qiu_sr-880))
					{
						MOTOLU=-Moto_zitai+135;
						MOTOLD=-Moto_zitai+135;
						MOTORU=-Moto_zitai-135;
						MOTORD=-Moto_zitai-135;
						if(baba==1)
						{
							OpenMV_data1=0;
							OpenMV_data2=0;
							OpenMV_data3=0;
							baba=0;
						}
					}
					else if(Total_Distance_LU>=(qiu_sl-880)&&Total_Distance_RU>=(qiu_sr-880))
					{
						if(mv_flag==1)
						{
							USART2_SendByte(0x01);
							mv_flag=0;
						}
						if(ma_flag==1)
						{
							if(OpenMV_data1>=154&&OpenMV_data1<=168)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								clear=1;
								if(t_flag==1)
								{
									TIM_Cmd(TIM2,ENABLE);
									t_flag=0;
								}
							}
							else if(OpenMV_data1==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(ma_flag==2)
						{
							if(OpenMV_data2>=154&&OpenMV_data2<=168)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								clear=1;
								if(t_flag==1)
								{
									TIM_Cmd(TIM2,ENABLE);
									t_flag=0;
								}
							}
							else if(OpenMV_data2==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(ma_flag==3)
						{
							if(OpenMV_data3>=154&&OpenMV_data3<=168)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								clear=1;
								if(t_flag==1)
								{
									TIM_Cmd(TIM2,ENABLE);
									t_flag=0;
								}
							}
							else if(OpenMV_data3==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
					}
				}
				else if(t==24)
				{
					time_inter=8;
					if(tt==12)
					{
						t_flag=1;
						GPIO_ResetBits(GPIOE, GPIO_Pin_0);
						GPIO_ResetBits(GPIOE, GPIO_Pin_15);
						tt=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
				}
				else if(t==25)
				{
					time_inter=1;
					if(guang==1)
					{
						GPIO_SetBits(GPIOE, GPIO_Pin_0);
						GPIO_SetBits(GPIOE, GPIO_Pin_15);
						guang=0;
					}
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU<(qiu_sl-90)&&Total_Distance_RU<(qiu_sr-90))
					{
						MOTOLU=-Moto_zitai+240;
						MOTOLD=-Moto_zitai+240;
						MOTORU=-Moto_zitai-240;
						MOTORD=-Moto_zitai-240;
					}
					else if(Total_Distance_LU>=(qiu_sl-90)&&Total_Distance_LU<(qiu_sl-60)&&Total_Distance_RU>=(qiu_sr-90)&&Total_Distance_RU<(qiu_sr-60))
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=(qiu_sl-60)&&Total_Distance_LU<(qiu_sl-30)&&Total_Distance_RU>=(qiu_sr-60)&&Total_Distance_RU<(qiu_sr-30))
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=(qiu_sl-30)&&Total_Distance_LU<qiu_sl&&Total_Distance_RU>=(qiu_sr-30)&&Total_Distance_RU<qiu_sr)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					else if(Total_Distance_LU>=qiu_sl&&Total_Distance_RU>=qiu_sr)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						tt=1;
						a24=1;
					}
				}
			}
			if(a24==1)//������ֱ���յ�ֹͣ0.2s
			{
				a23=0;
				s_time=0;
				s_flag=1;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a25=1;
			}
			if(a25==1)//������ֱ���յ���ת90��ʱ��3.5s
			{
				if(t==26)
				{
					a24=0;
					time_inter=6;
					angle_big=-180;
					MOTOLU=-Moto_zitai*1.12;
					MOTOLD=-Moto_zitai*1.12;
					MOTORU=-Moto_zitai*0.18;
					MOTORD=-Moto_zitai*0.18;
					if(s_flag==1)
					{
						Total_Distance_LU=0; 
						Total_Distance_RU=0;
						s_flag=0;
					}
					if(global_angle>=-181&&global_angle<=-179)
					{
						if(tt==1)
						{
							clear=1;
							t_flag=1;
							arm_flag=8;
							yuanzhu_flag=1;
							yuantai_flag=1;
							yaogu_flag=1;
							zhongdian_flag=1;
							tt=2;
						}
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					a26=1;
				}
			}
			if(a26==1)//���߶�ֱ��ʶ������
			{
				if(t==27)
				{
					a25=0;
					s_time=0.01;
					time_inter=1;
					angle_big=-180;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(guang==1)
					{
						USART1_SendByte(0x01);
						guang=0;
					}
					if(Total_Distance_LU>=0&&Total_Distance_LU<560&&Total_Distance_RU>=0&&Total_Distance_RU<560)
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=560&&Total_Distance_LU<710&&Total_Distance_RU>=560&&Total_Distance_RU<710)
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
						if(arm_flag==8)
						{
							duoji=11;
							bujin=2;
							arm_flag=0;
						}
					}
					else if(Total_Distance_LU>=710&&Total_Distance_LU<740&&Total_Distance_RU>=710&&Total_Distance_RU<740)
					{
						MOTOLU=-Moto_zitai+135;
						MOTOLD=-Moto_zitai+135;
						MOTORU=-Moto_zitai-135;
						MOTORD=-Moto_zitai-135;
						if(maixcam==1)
						{
							Maixcam_data1=0;
							Maixcam_data2=0;
							Maixcam_data3=0;
							maixcam=0;
						}
					}
					else if(Total_Distance_LU>=740&&Total_Distance_RU>=740)
					{
						if(Maixcam_data1>=1100&&Maixcam_data1<=1200)//Բ��
						{
							if(yuanzhu_flag==1)
							{
								dd=Total_Distance_LU;
								yuanzhu_flag=0;
							}
						}
						else if(Maixcam_data2>=1100&&Maixcam_data2<=1200)//Բ̨
						{
							if(yuantai_flag==1)
							{
								ee=Total_Distance_LU;
								yuantai_flag=0;
							}
						}
						else if(Maixcam_data3>=1100&&Maixcam_data3<=1200)//����
						{
							if(yaogu_flag==1)
							{
								ff=Total_Distance_LU;
								yaogu_flag=0;
							}
						}
						if(renzhi_flag==1)//Բ��
						{
							if(Maixcam_data1>=1000&&Maixcam_data1<=1100)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(ee==0&&ff==0)
								{
									zhongdian=1;
								}
								else if((dd>ee&&ff==0)||(dd>ff&&ee==0))
								{
									zhongdian=2;
								}
								else if(dd>ff&&dd>ee&&ff!=0&&ee!=0)
								{
									zhongdian=3;
								} 
								t_flag=1;
								s_time=0;
								s_flag=1;
								arm_flag=9;
								a27=1;
							}
							else if(Maixcam_data1==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(renzhi_flag==2)//Բ̨
						{
							if(Maixcam_data2>=1000&&Maixcam_data2<=1100)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(dd==0&&ff==0)
								{
									zhongdian=1;
								}
								else if((ee>dd&&ff==0)||(ee>ff&&dd==0))
								{
									zhongdian=2;
								}
								else if(ee>dd&&ee>ff&&ff!=0&&dd!=0)
								{	
									zhongdian=3;
								}
								t_flag=1;
								s_time=0;
								s_flag=1;
								arm_flag=9;
								a27=1;
							}
							else if(Maixcam_data2==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						else if(renzhi_flag==3)//����
						{
							if(Maixcam_data3>=1000&&Maixcam_data3<=1100)
							{
								MOTOLU=-Moto_zitai;
								MOTOLD=-Moto_zitai;
								MOTORU=-Moto_zitai;
								MOTORD=-Moto_zitai;
								if(ee==0&&dd==0)
								{
									zhongdian=1;
								}
								else if((ff>ee&&dd==0)||(ff>dd&&ee==0))
								{
									zhongdian=2;
								}
								else if(ff>ee&&ff>dd&&ee!=0&&dd!=0)
								{	
									zhongdian=3;
								}
								t_flag=1;
								s_time=0;
								s_flag=1;
								arm_flag=9;
								a27=1;
							}
							else if(Maixcam_data3==0)
							{
								MOTOLU=-Moto_zitai+120;
								MOTOLD=-Moto_zitai+120;
								MOTORU=-Moto_zitai-120;
								MOTORD=-Moto_zitai-120;
							}
							else
							{
								MOTOLU=-Moto_zitai+60;
								MOTOLD=-Moto_zitai+60;
								MOTORU=-Moto_zitai-60;
								MOTORD=-Moto_zitai-60;
							}
						}
						if(zhongdian==1)
						{
							if(zhongdian_flag==1)
							{
								renzhi_sl0=Total_Distance_LU;
								renzhi_sr0=Total_Distance_RU;
								renzhi_sl=renzhi_sl0+1725;
								renzhi_sr=renzhi_sr0+1725;
								zhongdian_flag=0;
							}
						}
						else if(zhongdian==2)
						{
							if(zhongdian_flag==1)
							{
								renzhi_sl0=Total_Distance_LU;
								renzhi_sr0=Total_Distance_RU;
								renzhi_sl=renzhi_sl0+1575;
								renzhi_sr=renzhi_sr0+1575;
								zhongdian_flag=0;
							}
						}
						else if(zhongdian==3)
						{
							if(zhongdian_flag==1)
							{
								renzhi_sl0=Total_Distance_LU;
								renzhi_sr0=Total_Distance_RU;
								renzhi_sl=renzhi_sl0+1425;
								renzhi_sr=renzhi_sr0+1425;
								zhongdian_flag=0;
							}
						}
					}
				}
			}
			if(a27==1)//���߶�ֱ�߾�Ԯ��ֹͣ0.2s
			{
				a26=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a28=1;
			}
			if(a28==1)//���߶�ֱ����ɾ�Ԯ
			{
				
				if(t==28)
				{
					a27=0;
					time_inter=12;
					if(arm_flag==9)//�½�3s
					{
						duoji=22;
						arm_flag=10;
					}
					if(tt==2)
					{
						t_flag=1;
						tt=3;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==29)
				{
					time_inter=3;
					if(arm_flag==10)//���1s
					{
						duoji=228;
						arm_flag=11;
					}
					if(tt==3)
					{
						t_flag=1;
						tt=4;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==30)
				{
					if(tt==4)
					{
						t_flag=1;
						tt=5;
					}
					time_inter=3;
					if(arm_flag==11)//��ȡ1s
					{
						duoji=33;
						arm_flag=0;
					}
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai; 
					MOTORD=-Moto_zitai;
				}
				else if(t==31)
				{
					if(tt==5)
					{
						t_flag=1;
						tt=6;
					}
					arm_flag=11;
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					s_time=0.01;
					MOTOLU=-Moto_zitai;
					MOTOLD=-Moto_zitai;
					MOTORU=-Moto_zitai;
					MOTORD=-Moto_zitai;
				}
				else if(t==32)
				{
					if(tt==6)
					{
						t_flag=1;
						tt=7;
					}
					time_inter=8;
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					if(arm_flag==11)//����1s
					{
						duoji=44;
						arm_flag=12;
					}
					MOTOLU=-Moto_zitai+180;
					MOTOLD=-Moto_zitai+180;
					MOTORU=-Moto_zitai-180;
					MOTORD=-Moto_zitai-180;
				}
				else if(t==33)
				{
					if(tt==7)
					{
						t_flag=1;
						tt=8;
					}
					time_inter=10;
					if(t_flag==1)
					{
						TIM_Cmd(TIM2,ENABLE);
						t_flag=0;
					}
					if(arm_flag==12)
					{
						bujin=100;
						arm_flag=0;
					}
					MOTOLU=-Moto_zitai+180;
					MOTOLD=-Moto_zitai+180;
					MOTORU=-Moto_zitai-180;
					MOTORD=-Moto_zitai-180;
					clear=1;
					a29=1;
				}
			}
			if(a29==1)//���߶�ֱ�ߵ����յ�
			{
				if(t==34)
				{
					a28=0;
					
					time_inter=1;
					if(clear==1)
					{
						Integral_bias1=0;
						Integral_bias2=0;
						clear=0;
					}
					if(Total_Distance_LU<(renzhi_sl-90)&&Total_Distance_RU<(renzhi_sr-90))
					{
						MOTOLU=-Moto_zitai+225;
						MOTOLD=-Moto_zitai+225;
						MOTORU=-Moto_zitai-225;
						MOTORD=-Moto_zitai-225;
					}
					else if(Total_Distance_LU>=(renzhi_sl-90)&&Total_Distance_LU<(renzhi_sl-60)&&Total_Distance_RU>=(renzhi_sr-90)&&Total_Distance_RU<(renzhi_sr-60))
					{
						MOTOLU=-Moto_zitai+210;
						MOTOLD=-Moto_zitai+210;
						MOTORU=-Moto_zitai-210;
						MOTORD=-Moto_zitai-210;
					}
					else if(Total_Distance_LU>=(renzhi_sl-60)&&Total_Distance_LU<(renzhi_sl-30)&&Total_Distance_RU>=(renzhi_sr-60)&&Total_Distance_RU<(renzhi_sr-30))
					{
						MOTOLU=-Moto_zitai+150;
						MOTOLD=-Moto_zitai+150;
						MOTORU=-Moto_zitai-150;
						MOTORD=-Moto_zitai-150;
					}
					else if(Total_Distance_LU>=(renzhi_sl-30)&&Total_Distance_LU<renzhi_sl&&Total_Distance_RU>=(renzhi_sr-30)&&Total_Distance_RU<renzhi_sr)
					{
						MOTOLU=-Moto_zitai+60;
						MOTOLD=-Moto_zitai+60;
						MOTORU=-Moto_zitai-60;
						MOTORD=-Moto_zitai-60;
					}
					if(Total_Distance_LU>=renzhi_sl&&Total_Distance_RU>=renzhi_sr)
					{
						MOTOLU=-Moto_zitai;
						MOTOLD=-Moto_zitai;
						MOTORU=-Moto_zitai;
						MOTORD=-Moto_zitai;
						t_flag=1;
						s_time=0;
						time_inter=5;
						s_flag=1;
						a30=1;
					}
				}
			}
			if(a30==1)//���߶�ֱ���յ�ֹͣ0.2s
			{
				a29=0;
				MOTOLU=-Moto_zitai;
				MOTOLD=-Moto_zitai;
				MOTORU=-Moto_zitai;
				MOTORD=-Moto_zitai;
				time=0;
				GPIO_ResetBits(GPIOE, GPIO_Pin_15);
				if(t_flag==1)
				{
					TIM_Cmd(TIM2,ENABLE);
					t_flag=0;
				}
				a31=1;
			}
			if(a31==1)//��ȫֹͣ���������
			{
				if(t==35)
				{
					a30=0;
					MOTOLU=0;
					MOTOLD=0;
					MOTORU=0;
					MOTORD=0;
					GPIO_SetBits(GPIOE, GPIO_Pin_15);
				}
			}
		}
		//��ʾ
		if(global_angle>0)
		{
			OLED_ShowString(0,0,(uint8_t *)"+",12,1);
			OLED_ShowFloat(8,0,global_angle,3,2,12,1);
		} 
		else if(global_angle<0)
		{
			OLED_ShowString(0,0,(uint8_t *)"-",12,1);
			OLED_ShowFloat(8,0,-global_angle,3,2,12,1);
		}
		else if(global_angle==0)
		{
			OLED_ShowString(0,0,(uint8_t *)" ",12,1);
			OLED_ShowFloat(8,0,0,3,2,12,1);
		}
		
		if(te>0)
		{
			OLED_ShowString(50,0,(uint8_t *)"+",12,1);
			OLED_ShowFloat(58,0,te,3,3,12,1);
		}
		else if(te<0)
		{
			OLED_ShowString(50,0,(uint8_t *)"-",12,1);
			OLED_ShowFloat(58,0,-te,3,3,12,1);
		}
		else if(te==0)
		{
			OLED_ShowString(50,0,(uint8_t *)" ",12,1);
			OLED_ShowFloat(58,0,0,3,3,12,1);
		}
		
		if(t>0)
		{
			OLED_ShowString(0,12,(uint8_t *)"+",12,1);
			OLED_ShowNum(8,12,t,2,12,1);
		}
		else if(t<0)
		{
			OLED_ShowString(0,12,(uint8_t *)"-",12,1);
			OLED_ShowNum(8,12,-t,2,12,1);
		}
		else if(t==0)
		{
			OLED_ShowString(0,12,(uint8_t *)" ",12,1);
			OLED_ShowNum(8,12,0,2,12,1);
		}
		
		if(key_count>0)
		{
			OLED_ShowString(30,12,(uint8_t *)"+",12,1);
			OLED_ShowNum(38,12,key_count,2,12,1);
		}
		else if(key_count<0)
		{
			OLED_ShowString(30,12,(uint8_t *)"-",12,1);
			OLED_ShowNum(38,12,-key_count,2,12,1);
		}
		else if(key_count==0)
		{
			OLED_ShowString(30,12,(uint8_t *)" ",12,1);
			OLED_ShowNum(38,12,0,2,12,1);
		}
		
		if(sure>0)
		{
			OLED_ShowString(60,12,(uint8_t *)"+",12,1);
			OLED_ShowNum(68,12,sure,3,12,1);
		}
		else if(sure<0)
		{
			OLED_ShowString(60,12,(uint8_t *)"-",12,1);
			OLED_ShowNum(68,12,-sure,3,12,1);
		}
		else if(sure==0)
		{
			OLED_ShowString(60,12,(uint8_t *)" ",12,1);
			OLED_ShowNum(68,12,0,3,12,1);
		}
		
		if((qiu_flag+ma_flag*10+renzhi_flag*100)>0)
		{
			OLED_ShowString(90,12,(uint8_t *)"+",12,1);
			OLED_ShowNum(98,12,(qiu_flag+ma_flag*10+renzhi_flag*100),3,12,1);
		}
		else if((qiu_flag+ma_flag*10+renzhi_flag*100)<0)
		{
			OLED_ShowString(90,12,(uint8_t *)"-",12,1);
			OLED_ShowNum(98,12,-(qiu_flag+ma_flag*10+renzhi_flag*100),3,12,1);
		}
		else if((qiu_flag+ma_flag*10+renzhi_flag*100)==0)
		{
			OLED_ShowString(90,12,(uint8_t *)" ",12,1);
			OLED_ShowNum(98,12,0,3,12,1);
		}
		
		if(Maixcam_data1>0)
		{
			OLED_ShowString(0,24,(uint8_t *)"+",12,1);
			OLED_ShowNum(8,24,Maixcam_data1,4,12,1);
		}
		else if(Maixcam_data1<0)
		{
			OLED_ShowString(0,24,(uint8_t *)"-",12,1);
			OLED_ShowNum(8,24,-Maixcam_data1,4,12,1);
		}
		else if(Maixcam_data1==0)
		{
			OLED_ShowString(0,24,(uint8_t *)" ",12,1);
			OLED_ShowNum(8,24,0,4,12,1);
		}
		
		if(Maixcam_data2>0)
		{
			OLED_ShowString(40,24,(uint8_t *)"+",12,1);
			OLED_ShowNum(48,24,Maixcam_data2,4,12,1);
		}
		else if(Maixcam_data2<0)
		{
			OLED_ShowString(40,24,(uint8_t *)"-",12,1);
			OLED_ShowNum(48,24,-Maixcam_data2,4,12,1);
		}
		else if(Maixcam_data2==0)
		{
			OLED_ShowString(40,24,(uint8_t *)" ",12,1);
			OLED_ShowNum(48,24,0,4,12,1);
		}
		
		if(Maixcam_data3>0)
		{
			OLED_ShowString(80,24,(uint8_t *)"+",12,1);
			OLED_ShowNum(88,24,Maixcam_data3,4,12,1);
		}
		else if(Maixcam_data3<0)
		{
			OLED_ShowString(80,24,(uint8_t *)"-",12,1);
			OLED_ShowNum(88,24,-Maixcam_data3,4,12,1);
		}
		else if(Maixcam_data3==0)
		{
			OLED_ShowString(80,24,(uint8_t *)" ",12,1);
			OLED_ShowNum(88,24,0,4,12,1);
		}
		
		if(OpenMV_data1>0)
		{
			OLED_ShowString(0,36,(uint8_t *)"+",12,1);
			OLED_ShowNum(8,36,OpenMV_data1,3,12,1);
		}
		else if(OpenMV_data1<0)
		{
			OLED_ShowString(0,36,(uint8_t *)"-",12,1);
			OLED_ShowNum(8,36,-OpenMV_data8,3,12,1);
		}
		else if(OpenMV_data1==0)
		{
			OLED_ShowString(0,36,(uint8_t *)" ",12,1);
			OLED_ShowNum(8,36,0,3,12,1);
		}
		
		if(OpenMV_data2>0)
		{
			OLED_ShowString(40,36,(uint8_t *)"+",12,1);
			OLED_ShowNum(48,36,OpenMV_data2,4,12,1);
		}
		else if(OpenMV_data2<0)
		{
			OLED_ShowString(40,36,(uint8_t *)"-",12,1);
			OLED_ShowNum(48,36,-OpenMV_data2,4,12,1);
		}
		else if(OpenMV_data2==0)
		{
			OLED_ShowString(40,36,(uint8_t *)" ",12,1);
			OLED_ShowNum(48,36,0,4,12,1);
		}
		
		if(OpenMV_data3>0)
		{
			OLED_ShowString(80,36,(uint8_t *)"+",12,1);
			OLED_ShowNum(88,36,OpenMV_data3,3,12,1);
		}
		else if(OpenMV_data3<0)
		{
			OLED_ShowString(80,36,(uint8_t *)"-",12,1);
			OLED_ShowNum(88,36,-OpenMV_data3,3,12,1);
		}
		else if(OpenMV_data3==0)
		{
			OLED_ShowString(80,36,(uint8_t *)" ",12,1);
			OLED_ShowNum(88,36,0,3,12,1);
		}
		
		if(OpenMV_data4>0)
		{
			OLED_ShowString(0,48,(uint8_t *)"+",12,1);
			OLED_ShowNum(8,48,OpenMV_data4,3,12,1);
		}
		else if(OpenMV_data4<0)
		{
			OLED_ShowString(0,48,(uint8_t *)"-",12,1);
			OLED_ShowNum(8,48,-OpenMV_data4,3,12,1);
		}
		else if(OpenMV_data4==0)
		{
			OLED_ShowString(0,48,(uint8_t *)" ",12,1);
			OLED_ShowNum(8,48,0,3,12,1);
		}
		
		if(OpenMV_data5>0)
		{
			OLED_ShowString(40,48,(uint8_t *)"+",12,1);
			OLED_ShowNum(48,48,OpenMV_data5,3,12,1);
		}
		else if(OpenMV_data5<0)
		{
			OLED_ShowString(40,48,(uint8_t *)"-",12,1);
			OLED_ShowNum(48,48,-OpenMV_data5,3,12,1);
		}
		else if(OpenMV_data5==0)
		{
			OLED_ShowString(40,48,(uint8_t *)" ",12,1);
			OLED_ShowNum(48,48,0,3,12,1);
		}
		
		if(OpenMV_data6>0)
		{
			OLED_ShowString(80,48,(uint8_t *)"+",12,1);
			OLED_ShowNum(88,48,OpenMV_data6,3,12,1);
		}
		else if(OpenMV_data6<0)
		{
			OLED_ShowString(80,48,(uint8_t *)"-",12,1);
			OLED_ShowNum(88,48,-OpenMV_data6,3,12,1);
		}
		else if(OpenMV_data6==0)
		{
			OLED_ShowString(80,48,(uint8_t *)" ",12,1);
			OLED_ShowNum(88,48,0,3,12,1);
		}
		OLED_Refresh();
	}
}

/***********************************************************
���������ݶ�ȡ
***********************************************************/
void TIM7_IRQHandler(void)//1ms��ȡ
{
	if(TIM_GetITStatus(TIM7,TIM_IT_Update)!=RESET)
	{
		V0=Get_V_value0();								//С������
		V2=Get_V_value2();								//С������
		
		encoder_LU_speed=Read_Speed(4);					//�ٶ�
		encoder_RU_speed=-Read_Speed(5);				//�ٶ�
		
		Get_Velocity(encoder_LU_speed,encoder_RU_speed);//·��
	}
	TIM_ClearITPendingBit(TIM7,TIM_IT_Update);
}
/***********************************************************
С���˶�����
***********************************************************/
void TIM6_DAC_IRQHandler(void)//1ms����
{
    if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
    {
		
		int Limit_Aspeed;
		
		Angle_PWM=Angle_PID(global_angle,angle_big);
		Limit_Aspeed=Xianfu(Angle_PWM,300);
		Moto_zitai=Aspeed_PID(-global_omega,Limit_Aspeed);
        
		Load(MOTOLU,MOTOLD,MOTORU,MOTORD);
		moto_pwm_limit(&MOTOLU,&MOTOLD,&MOTORU,&MOTORD);
    }
	TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
}

void TIM2_IRQHandler(void)//1s��ʱ
{
    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
    {
		
        time_temp++;
        if (time_temp >= time_inter) 
        {
            t++;
            time_temp = 0;
			TIM_Cmd(TIM2,DISABLE);
        }
        TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
    }
}

void TIM3_IRQHandler(void)//1ms����
{
    if (TIM_GetITStatus(TIM3, TIM_IT_Update) != RESET)
    {
		if(time==1)
		{
			te+=0.001f;
		}
		if(duoji==1)
		{
			Servo_y1_PWM+=1.5f;
			Servo_y2_PWM+=2.0f;
			Servo_y3_PWM-=2.0f;
			if(Servo_y1_PWM>=1585)
			{
				Servo_y1_PWM=1585;
			}
			if(Servo_y2_PWM>=250)
			{
				Servo_y2_PWM=250;
			}
			if(Servo_y3_PWM<=-1150)
			{
				Servo_y3_PWM=-1150;
			}
		}
		if(duoji==11)
		{
			Servo_y1_PWM+=1.0f;
			Servo_y3_PWM-=1.5f;
			Servo_m1_PWM+=0.5f;
			if(Servo_m1_PWM>=985)
			{
				Servo_m1_PWM=985;
			}
			if(Servo_y1_PWM>=700)
			{
				Servo_y1_PWM=700;
			}
			if(Servo_y3_PWM<=-800)
			{
				Servo_y3_PWM=-800;
			}
		}
		if(duoji==2)
		{
			Servo_y1_PWM+=2.0f;
			Servo_y2_PWM+=2.0f;
			Servo_j1_PWM+=2.5f;
			if(Servo_y1_PWM>=1710+(73-qiu_y))
			{
				Servo_y1_PWM=1710+(73-qiu_y);
			}
			if(Servo_y2_PWM>=(360+2.6*(73-qiu_y)))
			{
				Servo_y2_PWM=360+2.6*(73-qiu_y);
			}
			if(Servo_j1_PWM>=760)
			{
				Servo_j1_PWM=760;
			}
		}
		if(duoji==22)
		{
			Servo_y3_PWM-=2.5f;
			Servo_y1_PWM+=1.0f;
			Servo_y2_PWM-=2.5f;
			if(Servo_y3_PWM<=-1400)
			{
				Servo_y3_PWM=-1400;
			}
			if(Servo_y1_PWM>=1440)
			{
				Servo_y1_PWM=1440;
			}
			if(Servo_y2_PWM<=0)
			{
				Servo_y2_PWM=0;
			}
		}
		if(duoji==228)
		{
			Servo_y2_PWM+=2.0f;
			if(Servo_y2_PWM>=68)
			{
				Servo_y2_PWM=68;
			}
		}
		if(duoji==222)
		{
			Servo_y2_PWM+=0.5f;
			if(Servo_y2_PWM>=500)
			{
				Servo_y2_PWM=500;
			}
		}
		if(duoji==333)
		{
			Servo_y2_PWM-=0.5f;
			if(Servo_y2_PWM<=0)
			{
				Servo_y2_PWM=0;
			}
		}
		if(duoji==33)
		{
			Servo_j1_PWM+=2.5f;
			if(Servo_j1_PWM>=850)
			{
				Servo_j1_PWM=850;
			}
		}
		
		if(duoji==3)
		{
			Servo_y1_PWM+=2.5f;
			if(Servo_y1_PWM>=1200)
			{
				Servo_y1_PWM=1200;
			}
		}
		if(duoji==4)
		{
			Servo_y1_PWM+=1.0f;
			Servo_y2_PWM+=1.5f;
			if(Servo_y1_PWM>=(1560+(qiu_y-73)))
			{
				Servo_y1_PWM=1560+(qiu_y-73);
			}
			if(Servo_y2_PWM>=(315+(qiu_y-73)*2.6))
			{
				Servo_y2_PWM=315+(qiu_y-73)*2.6;
			}
		}
		if(duoji==5)
		{
			Servo_j1_PWM-=1.5f;
			if(Servo_j1_PWM<=0)
			{
				Servo_j1_PWM=0;
			}
		}
		if(duoji==6)
		{
			Servo_y1_PWM-=1.5f;
			Servo_y2_PWM-=1.5f;
			Servo_y3_PWM-=1.5f;
			if(Servo_y1_PWM<=0)
			{
				Servo_y1_PWM=0;
			}
			if(Servo_y2_PWM<=0)
			{
				Servo_y2_PWM=0;
			}
			if(Servo_y3_PWM<=-300)
			{
				Servo_y3_PWM=-300;
			}
		}
		if(duoji==66)
		{
			Servo_y1_PWM-=1.0f; 
			if(Servo_y1_PWM<=300)
			{
				Servo_y1_PWM=300;
			}
		}
		if(duoji==7)
		{
			Servo_y1_PWM+=1.5f;
			Servo_y2_PWM+=2.5f;
			if(Servo_y1_PWM>=(1430+(qiu_y-73)*1))
			{
				Servo_y1_PWM=1430+(qiu_y-73)*1;
			}
			if(Servo_y2_PWM>=(60+(qiu_y-73)*2.6))
			{
				Servo_y2_PWM=60+(qiu_y-73)*2.6;
			}
		}
		if(duoji==13)
		{
			if(mm==0)
			{
				Servo_m1_PWM+=5.0f;
				if(Servo_m1_PWM>=985)
				{
					Servo_m1_PWM=985;
					mm=1;
				}
			}
			if(mm==1)
			{
				Servo_m1_PWM+=0.15f;
				if(Servo_m1_PWM>=1055)
				{
					Servo_m1_PWM=1055;
					mm=2;
				}
			}
			if(mm==2)
			{
				Servo_m1_PWM-=0.15f;
				if(Servo_m1_PWM<=915)
				{
					Servo_m1_PWM=915;
					mm=1;
				}
			}
		}
		if(duoji==14)
		{
			Servo_m1_PWM-=5.0f;
			if(Servo_m1_PWM<=0)
			{
				Servo_m1_PWM=0;
			}
		}
		if(duoji==44)
		{
			Servo_y1_PWM-=1.2f;
			Servo_y2_PWM-=1.0f;
			Servo_m1_PWM-=2.0f;
			if(Servo_m1_PWM<=0)
			{
				Servo_m1_PWM=0;
			}
			if(Servo_y1_PWM<=0)
			{
				Servo_y1_PWM=0;
			} 
			if(Servo_y2_PWM<=0)
			{
				Servo_y2_PWM=0;
			}
		}
		
		TIM9 ->CCR1=560+Servo_y1_PWM;	//���560(560~2500)
		TIM9 ->CCR2=1150+Servo_y2_PWM;	//�б�820(820~2500)
		TIM11->CCR1=2500+Servo_y3_PWM;	//С��1480
		TIM10->CCR1=1400+Servo_j1_PWM;	//��צ1500(1500~2200)
		TIM13->CCR1=535+Servo_m1_PWM;
		
		TIM_ClearITPendingBit(TIM3, TIM_IT_Update);
	}
}

void USART6_IRQHandler(void)
{
    static uint8_t i=0;
    static uint8_t data_buf[9];
    if(USART_GetITStatus(USART6, USART_IT_RXNE) == SET)
    {
        uint8_t byte = USART_ReceiveData(USART6);
        if(i == 0 && byte != 0xA3) return;
        if(i == 1 && byte != 0xB3) { i=0; return; }
        data_buf[i++] = byte;
        if(i >= 9)
        {
            if(data_buf[8] == 0xC3)
            {
                Maixcam_data1 = data_buf[2]| (data_buf[3] << 8);
				Maixcam_data2 = data_buf[4]| (data_buf[5] << 8);
				Maixcam_data3 = data_buf[6]| (data_buf[7] << 8);
            }
            i = 0;
        }
        USART_ClearITPendingBit(USART6, USART_IT_RXNE);
    }
	else if (USART_GetITStatus(USART6, USART_IT_TXE) == SET) 
	{
        USART_SendData(USART6, txData6);
		USART_ITConfig(USART6, USART_IT_TXE, DISABLE);
        USART_ClearITPendingBit(USART6, USART_IT_TXE);
    }
}
void USART1_IRQHandler(void)
{
	static uint8_t i=0;
    static uint8_t data_buf[9];
    if(USART_GetITStatus(USART1, USART_IT_RXNE) == SET)
    {
        uint8_t byte = USART_ReceiveData(USART1);
        if(i == 0 && byte != 0xA3) return;
        if(i == 1 && byte != 0xB3) { i=0; return;}
        data_buf[i++] = byte;
        if(i >= 9)
        {
            if(data_buf[8] == 0xC3)
            {
                OpenMV_data4 = data_buf[2];
				OpenMV_data5 = data_buf[3];
				OpenMV_data6 = data_buf[4];
				OpenMV_data7 = data_buf[5];
				OpenMV_data8 = data_buf[6];
				OpenMV_data9 = data_buf[7];
            }
            i = 0;
        }
        USART_ClearITPendingBit(USART1, USART_IT_RXNE);
    }
	else if (USART_GetITStatus(USART1, USART_IT_TXE) == SET) 
	{
        USART_SendData(USART1, txData1);
		USART_ITConfig(USART1, USART_IT_TXE, DISABLE);
        USART_ClearITPendingBit(USART1, USART_IT_TXE);
    }
}
void USART2_IRQHandler(void)
{
	static uint8_t i=0;
    static uint8_t data_buf[6];
    if(USART_GetITStatus(USART2, USART_IT_RXNE) == SET)
    {
        uint8_t byte = USART_ReceiveData(USART2);
        if(i == 0 && byte != 0xA3) return;
        if(i == 1 && byte != 0xB3) { i=0; return; }
        data_buf[i++] = byte;
        if(i >= 6)
        {
            if(data_buf[5] == 0xC3)
            {
                OpenMV_data1 = data_buf[2];
				OpenMV_data2 = data_buf[3];
				OpenMV_data3 = data_buf[4];
            }
            i = 0;
        }
        USART_ClearITPendingBit(USART2, USART_IT_RXNE);
    }
	else if (USART_GetITStatus(USART2, USART_IT_TXE) == SET) 
	{
        USART_SendData(USART2, txData2);
		USART_ITConfig(USART2, USART_IT_TXE, DISABLE);
        USART_ClearITPendingBit(USART2, USART_IT_TXE);
    }
}
